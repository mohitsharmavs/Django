from django.shortcuts import render, redirect
from .forms import Login, Signup
from django.http import HttpResponse
# from .models import Adduser
from django.views import View
from django.core.mail import send_mail
from django.conf import settings
from random import randint
import csv
from wsgiref.util import FileWrapper as fw
# Create your views here.

def index(request):
    return render(request, "nav.html")

def login(request):
    f = Login()
    return render(request, "login.html", {"form" : f})

def signup(request):
    form = Signup()
    return render(request, "signup.html",{"form":form})

class aftersignup(View):
    def get(self, request):
        form = Signup()
        return render(request, 'signup.html', {"form" : form})
    
    def post(self, request):
        form = Signup(request.POST, request.FILES)
        if form.is_valid():
            data = {
            'email' : form.cleaned_data['email'],
            'password' : form.cleaned_data['password'],
            'firstname' : form.cleaned_data['firstname'],
            'lastname' : form.cleaned_data['lastname'],
            "image" : form.cleaned_data['image']
            }
            try:
                Adduser.objects.get(email = data['email'])
            except Exception as error:
                Adduser.objects.create(**data)
                form = Login()
                msg = "SUCESSFULLY REGISTERED"
                return render(request, "login.html",{"form" : form, "msg" : msg})
            else:
                form = Signup()
                msg = "User already exist"
                return render(request, "signup.html",{"form" : form, "msg" : msg})
        else:
            form = Signup()
            msg = "Invalid Form"
            return render(request, "signup.html",{"form" : form, "msg" : msg})
