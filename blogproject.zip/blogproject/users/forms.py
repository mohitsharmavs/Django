from django import forms

class Login(forms.Form):
    email = forms.EmailField(max_length=200, label="Enter Your Email", required=True, widget=forms.TextInput(attrs = {"placeholder" : "EMAIL"}))
    password = forms.CharField(widget=forms.PasswordInput, label="Enter Your Password")

class Signup(forms.Form):
    firstname = forms.CharField(max_length=100)
    lastname = forms.CharField(max_length=100)
    email = forms.EmailField()
    password = forms.CharField(max_length=200, widget=forms.PasswordInput)
    image = forms.ImageField()
